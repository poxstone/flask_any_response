#!/bin/sh

python3 main_server.py;
