#!/bin/sh
echo "${@}" | sh;